---
title: FastApiSpace
emoji: 🏢
colorFrom: purple
colorTo: red
sdk: docker
pinned: false
short_description: Fast Api
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
