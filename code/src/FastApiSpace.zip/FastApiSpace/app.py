from fastapi import FastAPI, FastAPI, Form, UploadFile, File, HTTPException
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
import torch
import os
import shutil
import fitz  # PyMuPDF for PDFs
import docx  # for Word documents
import uvicorn
import json
import torch.nn.functional as F
from tqdm import tqdm
from email import policy
from email.parser import BytesParser
from docx import Document
from PyPDF2 import PdfReader
import re
from datasets import Dataset, load_dataset
import requests

os.environ["WANDB_DISABLED"] = "true"

import torch.nn as nn
from transformers import AutoModel



app = FastAPI()


# Load request types and subcategories from loan-categories.json
with open("loan-categories.json", "r", encoding="utf-8") as f:
    categories_data = json.load(f)

# Load configuration for data priority
with open("config_x.json", "r", encoding="utf-8") as f:
    config = json.load(f)

DATA_PRIORITY = config.get("data_priority", "email_body")  # Default: Prioritize email body

class RequestData(BaseModel):
    text: str
    extracted_parameters: dict  # Includes Loan Amount, Loan ID, Borrower Name, etc.

# Define Multi-Label Model for Request Type & Sub Request Type
class MultiLabelClassifier(nn.Module):
    def __init__(self, model_name, num_request_types, num_sub_request_types):
        super(MultiLabelClassifier, self).__init__()
        self.base_model = AutoModel.from_pretrained(model_name)
        self.request_type_classifier = nn.Linear(self.base_model.config.hidden_size, num_request_types)
        self.sub_request_type_classifier = nn.Linear(self.base_model.config.hidden_size, num_sub_request_types)
        self.loss_fn = nn.CrossEntropyLoss()

    def forward(self, input_ids, attention_mask, labels=None):
        outputs = self.base_model(input_ids=input_ids, attention_mask=attention_mask)
        pooled_output = outputs.last_hidden_state[:, 0, :]  # Take CLS token output

        request_logits = self.request_type_classifier(pooled_output)
        sub_request_logits = self.sub_request_type_classifier(pooled_output)

        if labels is not None:
            request_loss = self.loss_fn(request_logits, labels[:, 0])  # First column: Request Type
            sub_request_loss = self.loss_fn(sub_request_logits, labels[:, 1])  # Second column: Sub Request Type
            loss = request_loss + sub_request_loss  # Sum both losses
            return loss, request_logits, sub_request_logits

        return request_logits, sub_request_logits  # Return raw logits during inference


# Create mappings for request types and subcategories
request_type_mapping = {category["name"]: idx for idx, category in enumerate(categories_data["categories"])}
print(request_type_mapping)
sub_request_mapping = {}
idx = 0  # Initialize idx before the loops
# Build mappings for subcategories & extractable parameters
extractable_params_mapping = {}

for category in categories_data["categories"]:
    idx = 0
    for sub in category["subcategories"]:
        sub_request_mapping[sub["name"]] = idx
        extractable_params_mapping[(category["name"], sub["name"])] = sub.get("extractable_parameters", [])
        idx += 1  # Increment idx for each subcategory


# Reverse mapping for decoding predictions later
reverse_request_mapping = {v: k for k, v in request_type_mapping.items()}
reverse_sub_mapping = {v: k for k, v in sub_request_mapping.items()}


# Load tokenizer & define model
MODEL_NAME = "bert-base-uncased"
#MODEL_NAME = "prosusai/finbert"
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
num_request_types = len(request_type_mapping)
num_sub_request_types = len(sub_request_mapping)
model = MultiLabelClassifier(MODEL_NAME, num_request_types, num_sub_request_types)

# Function to extract text from PDF files
def extract_text_from_pdf(file_path):
    text = ""
    with open(file_path, "rb") as f:
        reader = PdfReader(f)
        for page in reader.pages:
            text += page.extract_text() + "\n"
    return text.strip()

# Function to extract text from DOCX files
def extract_text_from_docx(file_path):
    doc = Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs])

# Function to extract text from `.txt` file
def extract_text_from_txt(txt_path):
    with open(txt_path, "r", encoding="utf-8") as f:
        return f.read()


# Function to extract text from an `.eml` file, including attachments
def extract_text_from_eml(eml_path, save_attachments=True, attachment_folder="attachments"):
    text = ""
    attachments_text = ""

    with open(eml_path, "rb") as f:
        msg = BytesParser(policy=policy.default).parse(f)

    # Extract email body
    if msg.is_multipart():
        for part in msg.iter_parts():
            content_type = part.get_content_type()
            if content_type == "text/plain":
                text += part.get_content()
            elif part.get_filename():  # Extract attachments
                if save_attachments:
                    os.makedirs(attachment_folder, exist_ok=True)
                    attachment_path = os.path.join(attachment_folder, part.get_filename())

                    with open(attachment_path, "wb") as f:
                        f.write(part.get_payload(decode=True))

                    # Extract text from the attachment if it's a supported format
                    if attachment_path.endswith(".pdf"):
                        attachments_text += extract_text_from_pdf(attachment_path)
                    elif attachment_path.endswith(".docx"):
                        attachments_text += extract_text_from_docx(attachment_path)
                    elif attachment_path.endswith(".txt"):
                        attachments_text += extract_text_from_txt(attachment_path)
    else:
        text = msg.get_content()

    # Combine email body and attachment text
    full_text = text + "\n\n" + attachments_text if attachments_text else text
    return full_text.strip()

# Function to extract key financial parameters
def extract_important_parameters(text, request_type, sub_request_type):
    extracted_params = {}

    # Get the parameters required for this request/sub-request
    parameters_to_extract = extractable_params_mapping.get((request_type, sub_request_type), [])

    # Define regex patterns for generic financial parameters
    patterns = {
        "Loan Amount": r"(\$\d{1,3}(?:,\d{3})*(?:\.\d{2})?)",
        "Loan ID": r"(LN-\d{4,6})",
        "Due Date": r"(\b(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4}\b)",
        "Transaction Reference": r"Ref[:\s]*([A-Z0-9-]+)",
        "Interest Rate": r"(\d{1,2}\.\d{1,2}% interest)",
        "Payment Date": r"(\b(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4}\b)",
        "Adjustment Amount": r"Adjustment[:\s]*\$(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)",
        "Effective Date": r"Effective[:\s]*(\b(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4}\b)"
    }

    # Extract only the required parameters
    for param in parameters_to_extract:
        extracted_params[param] = re.findall(patterns[param], text) if param in patterns else "Not Found"
        extracted_params[param] = extracted_params[param][0] if extracted_params[param] else "Not Found"

    return extracted_params

# Tokenize dataset
def preprocess_function(examples):
    inputs = tokenizer(examples["text"], truncation=True, padding="max_length", return_tensors="pt")
    labels = torch.tensor(examples["labels"], dtype=torch.long)
    return {**inputs, "labels": labels}


# Function to extract key financial parameters
def extract_all_possible_parameters(text):
    extracted_params = {}

    # Get the parameters required for this request/sub-request
    parameters_to_extract = ["Effective Date","Adjustment Amount","Payment Date","Interest Rate","Due Date","Loan Amount", "Loan ID", "Due Date", "Transaction Reference"]

    # Define regex patterns for generic financial parameters
    patterns = {
        "Loan Amount": r"(\$\d{1,3}(?:,\d{3})*(?:\.\d{2})?)",
        "Loan ID": r"(LN-\d{4,6})",
        "Due Date": r"(\b(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4}\b)",
        "Transaction Reference": r"Ref[:\s]*([A-Z0-9-]+)",
        "Interest Rate": r"(\d{1,2}\.\d{1,2}% interest)",
        "Payment Date": r"(\b(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4}\b)",
        "Adjustment Amount": r"Adjustment[:\s]*\$(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)",
        "Effective Date": r"Effective[:\s]*(\b(?:January|February|March|April|May|June|July|August|September|October|November|December) \d{1,2}, \d{4}\b)"
    }

    # Extract only the required parameters
    for param in parameters_to_extract:
        extracted_params[param] = re.findall(patterns[param], text) if param in patterns else "Not Found"
        extracted_params[param] = extracted_params[param][0] if extracted_params[param] else "Not Found"

    return extracted_params

def check_duplicate(file_path):
    url = "https://raocik-chromaSpacce.hf.space/duplicateCheck"
    files = {"file": open(file_path, "rb")}
    response = requests.post(url, files=files)
    #Pretty Print JSON Response
    return json.dumps(response.json(), indent=4)
    
@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    """
    Predicts the loan service request type based on extracted text & parameters.
    Returns RequestType, SubRequestType, Confidence Scores, and Extracted Parameters.
    """
    # Save uploaded file
    file_path = f"/tmp/{file.filename}"
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    file_name = file.filename
    if file_name.endswith(".eml"):
        text = extract_text_from_eml(file_path)
    elif file_name.endswith(".docx"):
        text = extract_text_from_docx(file_path)
    elif file_name.endswith(".pdf"):
        text = extract_text_from_pdf(file_path)
    else:
        return {
            "message": f"Model training failed due to unsupported file format"
        }

    model_path = "./WF_bert_model"
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    model = MultiLabelClassifier(MODEL_NAME, num_request_types, num_sub_request_types)
    model.load_state_dict(torch.load(os.path.join(model_path, "pytorch_model.bin")))
     # Extract relevant parameters dynamically
    extracted_parameters = extract_all_possible_parameters(text)

    # Concatenate extracted parameters into the input text for classification
    input_text = text + " | " + " | ".join(f"{key}: {value}" for key, value in extracted_parameters.items() if value != 'Not Found')

    inputs = tokenizer(input_text, return_tensors="pt", truncation=True, padding=True)

    # Remove token_type_ids from the inputs dictionary
    inputs = {k: v for k, v in inputs.items() if k in ["input_ids", "attention_mask"]}

    with torch.no_grad():
        request_logits, sub_request_logits = model(**inputs)

    # Apply softmax to get confidence scores
    request_probs = F.softmax(request_logits, dim=1).squeeze()
    sub_request_probs = F.softmax(sub_request_logits, dim=1).squeeze()
    # Get predicted labels
    request_type_pred = torch.argmax(request_logits, dim=1).item()
    sub_request_type_pred = torch.argmax(sub_request_logits, dim=1).item()

    request_confidence = request_probs[request_type_pred].item()
    sub_request_confidence = sub_request_probs[sub_request_type_pred].item()

    # Convert to human-readable labels
    predicted_request_type = reverse_request_mapping.get(request_type_pred, "Unknown")
    predicted_sub_request_type = reverse_sub_mapping.get(sub_request_type_pred, "Unknown")

    is_duplicate = False
    # Check if document is a duplicate
    response = json.loads(check_duplicate(file_path))
    is_duplicate = response["is_duplicate"]
    print(f"is duplicate: {is_duplicate}")
    
    return {
        "Primary Request Type": predicted_request_type,
        "Primary Request Confidence": f"{request_confidence:.2f}",
        "Sub Request Type": predicted_sub_request_type,
        "Sub Request Confidence": f"{sub_request_confidence:.2f}",
        "extracted_parameters": extracted_parameters,
        "is_duplicate":is_duplicate
    }



@app.post("/train")
async def train_model(
    requestType: str = Form(...),
    requestSubType: str = Form(...),
    file: UploadFile = File(...),
):
    """
    Fine-tunes the model based on requestType, requestSubType, and uploaded file (.eml, .pdf, .docx).
    Extracts data from email body, attachments, and documents dynamically.
    """
    training_data = []
    # Save uploaded file
    file_path = f"/tmp/{file.filename}"
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    file_name = file.filename
    if file_name.endswith(".eml"):
        text = extract_text_from_eml(file_path)
    elif file_name.endswith(".docx"):
        text = extract_text_from_docx(file_path)
    elif file_name.endswith(".pdf"):
        text = extract_text_from_pdf(file_path)
    else:
        return {
            "message": f"Model training failed due to unsupported file format"
        }
    primary_request_type = requestType
    sub_request_type = requestSubType

    print(primary_request_type)
    print(sub_request_type)
    print(request_type_mapping)
    # Extract parameters based on request type & subtype
    extracted_parameters = extract_important_parameters(text, primary_request_type, sub_request_type)

    # Generate structured training data
    training_data.append({
        "text": text,
        "request_type": primary_request_type,
        "sub_request_type": sub_request_type,
        "request_type_label": request_type_mapping[primary_request_type],
        "sub_request_type_label": sub_request_mapping[sub_request_type],
        "extracted_parameters": extracted_parameters
    })

    # Convert dataset to Hugging Face format
    dataset = Dataset.from_dict({
        "text": [
            f"{d['text']} | " +
            " | ".join(
                f"{param}: {d['extracted_parameters'].get(param, 'N/A')}"
                for param in extractable_params_mapping.get((d['request_type'], d['sub_request_type']), [])
            )
            for d in training_data
        ],
        "labels": [[d["request_type_label"], d["sub_request_type_label"]] for d in training_data]
    })

    dataset = dataset.map(preprocess_function, batched=True)
    

    # Define training arguments
    training_args = TrainingArguments(
        output_dir="./WF_bert_model",
        evaluation_strategy="no",
        save_strategy="epoch",
        learning_rate=2e-5,
        per_device_train_batch_size=4,
        per_device_eval_batch_size=4,
        num_train_epochs=5,
        weight_decay=0.01
    )

    trainer = Trainer(model=model, args=training_args, train_dataset=dataset)
    trainer.train()

    #model.save_pretrained("./trained_model")
    torch.save(model.state_dict(), os.path.join("./WF_bert_model", "pytorch_model.bin"))
    tokenizer.save_pretrained("./WF_bert_model")

    return {
        "message": f"Model trained successfully for {requestType} -> {requestSubType}",
        "Extracted Parameters": extracted_parameters
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=7860)