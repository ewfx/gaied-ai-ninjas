from fastapi import FastAPI, FastAPI, Form, UploadFile, File, HTTPException
from pydantic import BaseModel
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
import torch
import os
import shutil
import fitz  # PyMuPDF for PDFs
import docx  # for Word documents
import uvicorn
import json
import torch.nn.functional as F
from tqdm import tqdm
from email import policy
from email.parser import BytesParser
from docx import Document
from PyPDF2 import PdfReader
import re
from datasets import Dataset, load_dataset

os.environ["WANDB_DISABLED"] = "true"

import torch.nn as nn
from transformers import AutoModel

import chromadb
from sentence_transformers import SentenceTransformer
import datetime


app = FastAPI()

# Load configuration for data priority
with open("config_x.json", "r", encoding="utf-8") as f:
    config = json.load(f)

DATA_PRIORITY = config.get("data_priority", "email_body")  # Default: Prioritize email body

DOCUMENT_DUPLICITY_THRESHHOLD = float(config.get("document_duplicity_threshhold", 30)) / 100


# Initialize ChromaDB client
chroma_client = chromadb.PersistentClient(path="./chroma_db")  # Store database locally
collection = chroma_client.get_or_create_collection(name="documents")

# Load an embedding model (Use a lightweight model for speed)
embedding_model = SentenceTransformer("all-MiniLM-L6-v2")

def store_document(doc_id, content):
    """Embeds document content and stores in ChromaDB"""
    embedding = embedding_model.encode(content, normalize_embeddings=True).tolist()
    timestamp = datetime.datetime.utcnow().isoformat()

    collection.add(
        ids=[doc_id],
        embeddings=[embedding],
        metadatas=[{"content": content, "timestamp": timestamp}]
    )
    print(f"Stored Document: {doc_id}")

def check_duplicate(new_content, threshold=0.80):
    new_embedding = embedding_model.encode(new_content, normalize_embeddings=True).tolist()
    distance_threshold = 1 - threshold
    timeframe_threshold = (datetime.datetime.utcnow() - datetime.timedelta(days=30)).isoformat()

    results = collection.query(query_embeddings=[new_embedding], n_results=5)
    if not results["ids"] or not results["distances"]:
        return False

    for score, metadata in zip(results["distances"][0], results["metadatas"][0]):
        if score <= distance_threshold and metadata.get("timestamp", "") > timeframe_threshold:
            return True
    return False

    
# Function to extract text from PDF files
def extract_text_from_pdf(file_path):
    text = ""
    with open(file_path, "rb") as f:
        reader = PdfReader(f)
        for page in reader.pages:
            text += page.extract_text() + "\n"
    return text.strip()

# Function to extract text from DOCX files
def extract_text_from_docx(file_path):
    doc = Document(file_path)
    return "\n".join([para.text for para in doc.paragraphs])

# Function to extract text from `.txt` file
def extract_text_from_txt(txt_path):
    with open(txt_path, "r", encoding="utf-8") as f:
        return f.read()


# Function to extract text from an `.eml` file, including attachments
def extract_text_from_eml(eml_path, save_attachments=True, attachment_folder="attachments"):
    text = ""
    attachments_text = ""

    with open(eml_path, "rb") as f:
        msg = BytesParser(policy=policy.default).parse(f)

    # Extract email body
    if msg.is_multipart():
        for part in msg.iter_parts():
            content_type = part.get_content_type()
            if content_type == "text/plain":
                text += part.get_content()
            elif part.get_filename():  # Extract attachments
                if save_attachments:
                    os.makedirs(attachment_folder, exist_ok=True)
                    attachment_path = os.path.join(attachment_folder, part.get_filename())

                    with open(attachment_path, "wb") as f:
                        f.write(part.get_payload(decode=True))

                    # Extract text from the attachment if it's a supported format
                    if attachment_path.endswith(".pdf"):
                        attachments_text += extract_text_from_pdf(attachment_path)
                    elif attachment_path.endswith(".docx"):
                        attachments_text += extract_text_from_docx(attachment_path)
                    elif attachment_path.endswith(".txt"):
                        attachments_text += extract_text_from_txt(attachment_path)
    else:
        text = msg.get_content()

    # Combine email body and attachment text
    full_text = text + "\n\n" + attachments_text if attachments_text else text
    return full_text.strip()


  
@app.post("/duplicateCheck")
async def duplicateCheck(file: UploadFile = File(...)):
    """
    Predicts the loan service request type based on extracted text & parameters.
    Returns RequestType, SubRequestType, Confidence Scores, and Extracted Parameters.
    """
    # Save uploaded file
    file_path = f"/tmp/{file.filename}"
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    file_name = file.filename
    if file_name.endswith(".eml"):
        text = extract_text_from_eml(file_path)
    elif file_name.endswith(".docx"):
        text = extract_text_from_docx(file_path)
    elif file_name.endswith(".pdf"):
        text = extract_text_from_pdf(file_path)
    else:
        return {
            "message": f"Model training failed due to unsupported file format"
        }

    is_duplicate = False
    # Check if document is a duplicate
    is_duplicate = check_duplicate(text)

    # Store new document in ChromaDB if it's not a duplicate
    if not is_duplicate :
        print("doc was not duplicate")
        print(is_duplicate)
        doc_id = str(datetime.datetime.utcnow().timestamp())  # Unique ID based on timestamp
        store_document(doc_id, text)

    return {"is_duplicate": is_duplicate}


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=7860)