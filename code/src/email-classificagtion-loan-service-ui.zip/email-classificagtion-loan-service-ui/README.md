---
title: Loan Service Ui
emoji: 🏆
colorFrom: gray
colorTo: green
sdk: docker
pinned: false
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
