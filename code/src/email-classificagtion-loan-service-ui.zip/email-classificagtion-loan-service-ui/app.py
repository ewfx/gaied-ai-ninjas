import os
import json
import re
import requests
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify

app = Flask(__name__)
app.secret_key = "supersecret"

# File Paths
FILE_NAME = "loan-categories.json"
CONFIG_FILE_PATH = os.path.dirname(os.path.abspath(__file__))
FILE_PATH = os.path.join(CONFIG_FILE_PATH,'models',FILE_NAME)
# Load categories
def load_categories():
    try:
        if os.path.exists(FILE_PATH):
            with open(FILE_PATH, "r", encoding="utf-8") as f:
                json_categories = (json.load(f))
                return json_categories
    except Exception as e:
        return {"categories": []}

@app.route("/")
def home():
    return render_template("home.html")

# 🔹 ADMIN PANEL: Upload loan-categories.json
@app.route("/admin", methods=["GET", "POST"])
def admin():
    try:
        if request.method == "GET":
            print("in get method admin")
            return render_template("admin.html")
        if request.method == "POST":
            print("in post method admin")
            file = request.files["config_file"]
            if file and file.filename.endswith(".json"):
                print("file name",FILE_NAME)
                file.save(FILE_NAME)
                flash("Configuration updated successfully!", "success")
                return redirect(url_for("admin"))
            flash("Invalid file format. Please upload a JSON file.", "danger")
        return render_template("admin.html")
    except Exception as e:
        print("exception in admin",e)
        return render_template(admin.html)

# 🔹 TRAINER PANEL: Upload training documents
@app.route("/train", methods=["GET", "POST"])
def train():
    try:
        categories = load_categories()
        print("categories",categories)
        sub_categories_on_page_load = load_sub_categories('Adjustment')
        print("sub categories",sub_categories_on_page_load)
        if request.method == "POST":
            request_type = request.form["requestType"]
            sub_type = request.form["requestSubType"]
            file = request.files["train_file"]
            
            if file:
                files = {"file": file}
                data = {"requestType": request_type, "requestSubType": sub_type}
                response = requests.post("https://raocik-fastapispace.hf.space/train", files=files, data=data)
                flash(response.json().get("message", "Training failed"), "success")
                
        return render_template("train.html", categories=categories["categories"], sub_categories=sub_categories_on_page_load)
    except Exception as e:
        print(f"Error training model: {e}")
        return render_template("train.html", categories=[], sub_categories=[])

def load_sub_categories(category_name):
    try:
        categories = load_categories()
        selected_category = next((c for c in categories["categories"] if c["name"] == category_name), None)
        if not selected_category:
            return []
        return [sub["name"] for sub in selected_category["subcategories"]]
    except Exception as e:
        print(f"Error loading subcategories: {e}")
        return []
    


# 🔹 END USER PANEL: Upload documents for classification
@app.route("/predict", methods=["GET", "POST"])
def predict():
    prediction = None
    if request.method == "POST":
        file = request.files["doc_file"]
        if file:
            files = {"file": file}
            response = requests.post("https://raocik-fastapispace.hf.space/predict", files=files)
            prediction = response.json()
    
    return render_template("predict.html", prediction=prediction)

@app.route("/get_subcategories")
def get_subcategories():
    try:
        """Returns subcategories based on selected request type"""
        category_name = request.args.get("category")
        categories = load_categories()

        selected_category = next((c for c in categories["categories"] if c["name"] == category_name), None)
        if not selected_category:
            return jsonify({"subcategories": []})

        subcategories = [sub["name"] for sub in selected_category["subcategories"]]
        return jsonify({"subcategories": subcategories})
    except Exception as e:
        print(f"Error loading subcategories: {e}")
        return jsonify({"subcategories": []})
    

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7860)

