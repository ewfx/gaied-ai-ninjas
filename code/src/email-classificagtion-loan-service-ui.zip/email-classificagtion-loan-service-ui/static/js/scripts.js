document.addEventListener("DOMContentLoaded", function () {
    const requestTypeDropdown = document.getElementById("requestType");
    const requestSubTypeDropdown = document.getElementById("requestSubType");

    if (requestTypeDropdown) {
        requestTypeDropdown.addEventListener("change", function () {
            const selectedCategory = this.value;
            requestSubTypeDropdown.innerHTML = '<option value="">Select Sub Category</option>';

            fetch("/get_subcategories?category=" + encodeURIComponent(selectedCategory))
                .then(response => response.json())
                .then(data => {
                    data.subcategories.forEach(sub => {
                        const option = document.createElement("option");
                        option.value = sub;
                        option.textContent = sub;
                        requestSubTypeDropdown.appendChild(option);
                    });
                })
                .catch(error => console.error("Error loading subcategories:", error));
        });
    }

    // Display file name on upload
    document.getElementById("fileInput")?.addEventListener("change", function () {
        let fileLabel = document.getElementById("fileLabel");
        fileLabel.textContent = this.files[0]?.name || "Choose file";
    });
});
